
to use basemap you need to install the following  :
!apt install proj-bin libproj-dev libgeos-dev
!pip install https://github.com/matplotlib/basemap/archive/v1.2.0rel.tar.gz

mpl_toolkits.basemap is used to draw a world map and you can print numbers on the map and draw circles using code ,this helps in drwing some statistics in very clear way if it belongs to world countries .

sikit-learn: known sklearn this is machine learning libraries that contains most famous machine learning models and also contains modules for data preprocessing ....etc.


matplot lib :is used for data visualization to draw histograms or bar charts.
numpy: linear algebra library make it easy to doing mathemtical calculcation and array manipulation. .
pandas :enables to read data from excel or csv file into a data frame to use it to apply algorithms or analysis on the data using programming.
